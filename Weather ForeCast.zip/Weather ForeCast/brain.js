const apiKEY = "62c613872387921c6256edf11653dd15";
const apiURL = "https://api.openweathermap.org/data/2.5/weather?&units=metric&q=";

const Searchbox = document.querySelector(".search input");
const Searchbtn = document.querySelector(".btn");
const Weatherimage = document.querySelector(".weather_icon");
const displayFull = document.querySelector(".weather");
const errorMsg = document.querySelector(".error");

async function checkWeather(city) {
  const response = await fetch(apiURL + city + `&appid=${apiKEY}`);
  if (response.status == "404") {
    errorMsg.style.display = "block";
    displayFull.style.display = "none";

  } else {
    const data = await response.json();
    console.log(data);

    document.querySelector(".city").innerHTML = data.name;
    document.querySelector(".temperature").innerHTML = Math.floor(data.main.temp) + "°C";
    document.querySelector(".humidity").innerHTML = data.main.humidity + "%";
    document.querySelector(".Wind").innerHTML = data.wind.speed + "km/h";

    if(data.weather[0].main == "Clouds") {
      Weatherimage.src = "images/clouds.png";
  
    }else if (data.weather[0].main == "Clear"){
      Weatherimage.src = "images/Clear.png";
    }else if (data.weather[0].main == "Rain"){
      Weatherimage.src = "images/rain.png";
    }else if (data.weather[0].main == "Mist"){
      Weatherimage.src = "images/mist.png";
    }else if (data.weather[0].main == "Drizzle"){
      Weatherimage.src = "images/drizzle.png";
    }else if (data.weather[0].main == "Wind"){
      Weatherimage.src = "images/wind.png";
    }else if (data.weather[0].main == "Snow"){
      Weatherimage.src = "images/snow.png";
    }
    displayFull.style.display = "block";
    errorMsg.style.display = "none";
  }
}

Searchbtn.addEventListener("click", () => {
  checkWeather(Searchbox.value);
});
